package com.example.model;

public class Recipe {

}
